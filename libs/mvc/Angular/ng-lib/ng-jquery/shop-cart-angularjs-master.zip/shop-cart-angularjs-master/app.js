'use strict';

var shoppingApp = angular.module('shoppingApp', [])
  .config(['$routeProvider', function($routeProvider) {
    $routeProvider
      .when('/', {
        templateUrl: 'templates/catalog.html'
      })
      .when('/checkout', {
        templateUrl: 'templates/checkout.html',
        controller: 'CheckoutCtrl'
      })
      .when('/cart', {
        templateUrl: 'templates/cart.html'
      })
      .when('/order', {
        templateUrl: 'templates/order.html',
        controller: 'OrderCtrl'
      })
      .otherwise({
        redirectTo: '/'
      });
  }]);
