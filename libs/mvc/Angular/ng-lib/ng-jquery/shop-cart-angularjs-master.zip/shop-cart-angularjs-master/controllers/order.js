'use strict';

shoppingApp.controller('OrderCtrl', function($scope) {
  $scope.clearCart();
});
