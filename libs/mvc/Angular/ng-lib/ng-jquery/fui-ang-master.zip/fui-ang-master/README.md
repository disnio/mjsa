fui-ang
=======

Angular.js wrapper for flat ui pro components. It's only angular directives wrapping for jQuery plugins.

## Description
This is a simple angular.js wrappers for **flat ui pro jquery widgets**. If you want to using it, you must get designmodo licence for **flat ui pro**. You alsow need angular.js 1.2.* and twitter bootstrap 3.1.* or older.

## Install

```
bower install --save fui-ang
```

## Components
Now have been added the following components:

* **fui-alert**: wrap for flat ui pro alerts;
* **fui-fileinput**: wrap for flat ui pro file inputs;
* **fui-modal**: wrap flat ui pro modal;
* **fui-checkbox**: wrap flat ui pro checkbox.

I want to add some directives for another widgets: switcher, radio button, progress, calendar, tag input, and also add some custom controls witch I've develop for myself.

## Examples

### fui-alert

Restyled Bootstrap alerts with no change to the functionality.

You need to add **fuialert** tag in your html code:
```html
<fuialert data="alert" ng-if="alert.isShow">
```
Fuialert are using specified model **alert**. If you want to set fuialert property from your controller, you must add this model:
```js
            $scope.alert = {
                isShow: true,
                isSuccess: 'info',
                header: 'This is a simple info alert',
                text: $sce.trustAsHtml('This is a simple text <a>some link</a>')
            }
```
Here description properties of model

* **isShow**: determines whether or not probably alert. Work with **ng-if**;
* **isSuccess**: this is a css selector. It can take the following values: true - 'alert-success', false - 'alert-danger', info - 'alert-info', warning - 'alert-warning'. Each value corresponds to a certain style;
* **header**: alert's header;
* **text**: alert's text. Can be as html markup. Must to prepare with angular **$sce** service.

You also can use innner html markup:

```html
                <fuialert data="alert" ng-if="alert.isShow">
                    <p>This is a simple text of ui value</p>
                    <button class="btn btn-info btn-wide">Close</button>
                    <button class="btn btn-danger btn-wide">Submit</button>
                </fuialert>
```
If you use the internal markup that **alert.text** will be ignore.

### fui-file

![alt tag](https://raw.githubusercontent.com/valeravorobjev/fui-ang/master/img/fuifile.png)

This is a wrap fro flat ui pro file input

```html
<fuifile text="Select a file" change-text="Change text" delete-text="Delete file" name="f1"/>
```

### fui-modal

![alt tag](https://raw.githubusercontent.com/valeravorobjev/fui-ang/master/img/fuimodal.png)

This is wrap for the restyled Bootstrap modal by flat ui. 

To open and close the modal window must use the attribute open 
and bollean variable

This is a controller:

```js
    $scope.isShow = false;
    $scope.openModal = function(){
        $scope.isShow = true;
    };
    $scope.closeModal = function(){
        $scope.isShow = false;
    }
```

Look at html markup:

```html
<fuimodal open="isShow">
    <div class="modal-header">
        <button type="button" class="close fui-cross" data-dismiss="modal" aria-hidden="true"></button>
        <h4 class="modal-title">Modal header</h4>
    </div>

    <div class="modal-body">
        <p>Modal content = {{2 + 2}}</p>
    </div>

    <div class="modal-footer">
        <button class="btn btn-primary btn-wide" ng-click="closeModal()" >Ok</button>
        <button class="btn btn-danger btn-wide" data-dismiss="modal">Cancel</button>
    </div>
</fuimodal>
```

There is a variable **isShow** in the html markup. It determines modal state, open or close.

```html
<fuimodal open="isShow"> 
```

Html text in the **fuimodal** body is a modal content.

### fui-checkbox

![alt tag](https://raw.githubusercontent.com/valeravorobjev/fui-ang/master/img/checkboxes.png)

Wrap for flat ui pro checkbox.

```html
<fuicheckbox ng-repeat="car in cars" checked="car.checked" value="{{car.speed}}" text="{{car.name}}"/>
```

```js
    $scope.cars = [
        {
            name: 'bmv',
            speed: 300,
            checked: false
        },
        {
            name: 'volkswagen',
            speed: 200,
            checked: false
        },
        {
            name: 'ford',
            speed: 100,
            checked: false
        },
        {
            name: 'C++ program language',
            speed: 777,
            checked: true
        }
    ];
```

Fuicheckbox must contains these attrs:

* **checked** - it's a required model variable for watching checkbox status: true - checked, false - unchecked;
* **value** - it's a checkbox value attr. Interpolate value with {{}};
* **text** - this is a checkbox text. Interpolate value with {{}};
* **id** - checkbox id attr. You need set number and directive concat it with 'checkbox' text.
