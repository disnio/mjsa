AngularJS Directive for auto expanding textareas.

More details to come...

Inspired by: https://github.com/jevin/Autogrow-Textarea