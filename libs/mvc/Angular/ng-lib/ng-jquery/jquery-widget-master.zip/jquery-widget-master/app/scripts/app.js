'use strict';

/**
 * @ngdoc overview
 * @name jqueryWrapperApp
 * @description
 * # jqueryWrapperApp
 *
 * Main module of the application.
 */
angular.module('jqueryWrapperApp', ['jqueryWidget', 'menu', 'progressbar', 'slider', 'spinner']);
