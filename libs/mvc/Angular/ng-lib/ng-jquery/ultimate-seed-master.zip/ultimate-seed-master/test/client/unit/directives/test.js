/*
 * test/client/directives/test.js
 */

/* globals chai, describe, it */
'use strict';

chai.should();

describe('testDirective', function () {
  it('should work', function () {
    [].length.should.equal(0);
  });
});
