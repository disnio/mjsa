/*
 * test/client/filters/home.js
 */

/* globals chai, describe, it */
'use strict';

chai.should();

describe('testFilter', function () {
  it('should work', function () {
    [].length.should.equal(0);
  });
});
