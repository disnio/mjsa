/*
 * test/client/globals.js
 */

/* globals beforeEach */
beforeEach(module('ngApp'));
