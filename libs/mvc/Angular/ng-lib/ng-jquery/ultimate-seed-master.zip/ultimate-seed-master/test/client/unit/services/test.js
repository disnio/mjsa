/*
 * test/client/services/home.js
 */

/* globals chai, describe, it */
'use strict';

chai.should();

describe('testService', function () {
  it('should work', function () {
    [].length.should.equal(0);
  });
});
