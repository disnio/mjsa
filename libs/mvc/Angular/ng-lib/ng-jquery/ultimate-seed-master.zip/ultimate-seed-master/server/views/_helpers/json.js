/*
 * server/views/_helpers/json.js
 */

'use strict';

exports = module.exports = function (context) {
  return JSON.stringify(context);
};
