/*
 * server/index.js
 */

'use strict';

exports = module.exports = require('./app').run();
