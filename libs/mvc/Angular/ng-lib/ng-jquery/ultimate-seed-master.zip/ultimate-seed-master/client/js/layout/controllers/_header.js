/*
 * client/js/layout/controllers/_header.js
 */

'use strict';

exports = module.exports = function (ngModule) {
  ngModule.controller('_HeaderCtrl', function () {

  });
};
