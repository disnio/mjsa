/*
 * client/js/layout/controllers/_footer.js
 */

'use strict';

exports = module.exports = function (ngModule) {
  ngModule.controller('_FooterCtrl', function () {
    
  });
};
