/*
 * client/js/account/controllers/_layout.js
 */

'use strict';

exports = module.exports = function (ngModule) {
  ngModule.controller('_LayoutCtrl', function () {

  });
};
