/*
 * client/js/admin/controllers/dashboard.js
 */

'use strict';

exports = module.exports = function (ngModule) {
  ngModule.controller('DashboardCtrl', function () {

  });
};
