/*
 * client/js/admin/controllers/_layout.js
 */

'use strict';

exports = module.exports = function (ngModule) {
  ngModule.controller('_LayoutCtrl', function () {

  });
};
