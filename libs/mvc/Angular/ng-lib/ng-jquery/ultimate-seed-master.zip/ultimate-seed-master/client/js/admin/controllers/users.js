/*
 * client/js/admin/controllers/users.js
 */

'use strict';

exports = module.exports = function (ngModule) {
  ngModule.controller('UsersCtrl', function () {

  });
};
