jquery-textntags-angular
========================

jquery-textntags-angular

> Criação de uma diretiva angular usando o plugin jquery jquery-textntags-angular
