trying jquery + anglarjs with directives
