var customDir = angular.module('customDir', ['ngRoute', 'customDirControllers']);

customDir.config(['$routeProvider',
                  function($routeProvider) {
                      $routeProvider.
                          when('/dirs', {
                              templateUrl: 'p/dir.html',
                              controller: 'ImgListCtrl'
                          }).otherwise({ redirectTo: '/dirs'});
                  }
]);


customDir.directive('justified', ['$timeout', function($timeout) {
    return {
        restrict: 'AE',
        link: function (scope, el, attrs) {
            scope.$watch('$last', function (n, o) {
                if(n) {
                    $timeout(function() {$(el[0]).justifiedGallery(); });
                }
            });
        }

    };
}]);

customDir.directive('repeatDone', [function () {
  return {
      restrict: 'A',
      link: function (scope, element, iAttrs) {
         var parentScope = element.parent().scope();
         if (scope.$last){
              parentScope.$last = true;           
          }
     }
  };
}]);

var customDirControllers = angular.module('customDirControllers', []);

customDirControllers.controller('ImgListCtrl', ['$scope',
   function($scope) {
      $scope.dirs = [
         {id: 1, 
          name: "Dir 1",
          first_image: "http://kleiberweb.de/1.4.Garda/slides/2009.09.13%20327.JPG"},
         {id: 2, 
          name: "Dir 2",
          first_image: "http://kleiberweb.de/1.3.Toskania/slides/IMG_5515.JPG"},
         {id: 3, 
          name: "Dir 3",
          first_image: "http://kleiberweb.de/1.5.London/slides/02.04.10%20097.JPG"},
         {id: 4, 
          name: "Dir 4",
          first_image: "http://kleiberweb.de/1.6.Trieste/slides/IMG_0717.JPG"},
         {id: 5, 
          name: "Dir 5",
          first_image: "http://kleiberweb.de/1.8.Alvhaga/slides/IMG_4528.JPG"},

      ];
   }]);
