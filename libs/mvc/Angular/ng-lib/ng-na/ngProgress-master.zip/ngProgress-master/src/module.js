// Here we define the maim module for easy dependency injection into other modules
angular.module('ngProgress', ['ngProgress.directive', 'ngProgress.provider']);