angular-jquery-ui-accordion
===========================

An angular accordion control which wraps the jquery ui accordion.  Better for my use case than the bootstrap accordion wrappers, as it fits to the height of its container.