basePath = '..';
files = [
  JASMINE,
  JASMINE_ADAPTER,
  'bower_components/jquery/dist/jquery.js',
  'bower_components/jquery-ui/jquery-ui.min.js',
  'bower_components/angular/angular.js',
  'bower_components/angular-mocks/angular-mocks.js',
  'src/date.js',
  'test/*.spec.js'
];
singleRun = true;
browsers = [ 'Chrome' ];