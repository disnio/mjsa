module.exports = {
  coveredFunction
};

function coveredFunction() {
  function manipulateableCoveredFunction() {
  }
  manipulateableCoveredFunction();
  return manipulateableCoveredFunction;
}
coveredFunction();
