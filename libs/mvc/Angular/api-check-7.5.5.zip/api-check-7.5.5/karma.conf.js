/* eslint-env node */
module.exports = require('kcd-common-tools/shared/karma.conf');
