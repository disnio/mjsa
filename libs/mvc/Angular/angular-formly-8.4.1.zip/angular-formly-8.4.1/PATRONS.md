# Patrons

The work on angular-formly is [funded by the community](https://www.patreon.com/kentcdodds).
Meet some of the outstanding companies and individuals that made it possible:

- [Pascal DeMilly](https://twitter.com/pdemilly)
- [Benjamin Orozco](https://twitter.com/benoror)

