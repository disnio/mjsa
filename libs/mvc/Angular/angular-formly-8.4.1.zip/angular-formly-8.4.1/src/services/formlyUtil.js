import utils from '../other/utils'

export default formlyUtil

// @ngInject
function formlyUtil() {
  return utils
}
