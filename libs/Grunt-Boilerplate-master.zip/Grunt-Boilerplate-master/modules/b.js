define(function(){
    return 'Module B loaded';
});