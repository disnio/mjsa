define(function(){
    return 'Module C loaded';
});