define(function(){
    return 'Module A loaded';
});