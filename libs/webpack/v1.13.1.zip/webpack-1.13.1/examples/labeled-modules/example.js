require: "./increment";
var a = 1;
increment(a); // 2