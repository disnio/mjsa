module.exports = {
	module: {
		loaders: [
			{ test: /\.json$/, loader: "json" }
		]
	}
}