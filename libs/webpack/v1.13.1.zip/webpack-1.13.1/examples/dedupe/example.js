var a = require("./a");
var b = require("./b");
a.x !== b.x;
a.y !== b.y;