
# example.js

``` javascript
{{example.js}}
```

# a/index.js

``` javascript
{{a/index.js}}
```

# a/x.js

``` javascript
{{a/x.js}}
```

# a/y.js

``` javascript
{{a/y.js}}
```

# b/index.js

``` javascript
{{b/index.js}}
```

# b/x.js

``` javascript
{{b/x.js}}
```

# b/y.js

``` javascript
{{b/y.js}}
```

# z.js

``` javascript
{{z.js}}
```

# js/output.js

``` javascript
{{js/output.js}}
```

# Info

## Uncompressed

```
{{stdout}}
```

## Minimized (uglify-js, no zip)

```
{{min:stdout}}
```