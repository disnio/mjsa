
# example.js

``` javascript
{{example.js}}
```

# worker.js

``` javascript
{{worker.js}}
```

# js/output.js

``` javascript
{{js/output.js}}
```

# js/[hash].worker.js

``` javascript
{{js/hash.worker.js}}
```

# js/1.[hash].worker.hs

``` javascript
{{js/1.hash.worker.js}}
```

# Info

## Uncompressed

```
{{stdout}}
```

## Minimized (uglify-js, no zip)

```
{{min:stdout}}
```