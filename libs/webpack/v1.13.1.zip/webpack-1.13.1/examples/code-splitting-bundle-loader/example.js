require("bundle!./file.js")(function(fileJsExports) {
	console.log(fileJsExports);
});