module.exports = "pageA";
require("./vendor1");
require("./vendor2");
