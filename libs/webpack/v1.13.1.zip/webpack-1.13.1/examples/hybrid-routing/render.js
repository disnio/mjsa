module.exports = function(page) {
	console.log(page());
};