require("./style.css");
require("./styleA.css");
