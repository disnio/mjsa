exports.beautify = {
	files: "{{lib,hot,scripts,bin}/**/*.js,{benchmark,test}/*.js}"
};
