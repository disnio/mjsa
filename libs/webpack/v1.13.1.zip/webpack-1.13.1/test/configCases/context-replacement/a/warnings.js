module.exports = [
	[/Critical dependencies/, /a\/index\.js/]
];