module.exports = [
	[/Critical dependencies/, /c\/index\.js/]
];