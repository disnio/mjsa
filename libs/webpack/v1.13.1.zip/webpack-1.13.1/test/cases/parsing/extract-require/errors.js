module.exports = [
	[/Module not found/, /Cannot resolve/, / \.\/missingModule /, /extract-require\/index.js/]
];