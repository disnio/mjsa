it("should compile expr in ?: operator", function() {
	require("./dir/test");
});
