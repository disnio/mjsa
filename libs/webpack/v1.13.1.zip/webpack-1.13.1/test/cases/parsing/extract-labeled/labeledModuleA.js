require: "./labeledModuleB";

exports: x, y, z;

exports: function foo(){ return "foo"; };
