exports: var x = "x", y = function() { return "y"; };

var z = "z";
exports: z;