module.exports = [
	[/Module parse failed/, /dump-file\.txt/, /templates \^\\\.\\\/\.\*\$/],
	[/Critical dependencies/, /templateLoader\.js/],
	[/Critical dependencies/, /templateLoaderIndirect\.js/],
	[/Critical dependencies/, /templateLoaderIndirect\.js/],
];