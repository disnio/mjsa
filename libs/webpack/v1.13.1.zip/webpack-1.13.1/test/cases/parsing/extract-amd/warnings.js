module.exports = [
	[/Module not found/, /Cannot resolve/, / \.\/b /, /b\.js/]
];
