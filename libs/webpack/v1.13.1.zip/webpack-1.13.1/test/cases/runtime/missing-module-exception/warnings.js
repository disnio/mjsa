module.exports = [
	[/Module not found/, /Cannot resolve/, / \.\/fail /]
];