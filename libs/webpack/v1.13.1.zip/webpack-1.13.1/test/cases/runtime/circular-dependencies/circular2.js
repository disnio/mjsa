module.exports = 2;
module.exports = require("./circular2");