module.exports = __webpack_amd_options__;
