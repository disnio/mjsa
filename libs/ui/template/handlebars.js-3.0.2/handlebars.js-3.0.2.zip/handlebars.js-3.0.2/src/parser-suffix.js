export default handlebars;
/* jshint ignore:end */
