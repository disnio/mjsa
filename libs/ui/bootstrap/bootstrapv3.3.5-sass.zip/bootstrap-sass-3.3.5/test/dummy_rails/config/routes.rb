Dummy::Application.routes.draw do
  root to: 'pages#root'
end
