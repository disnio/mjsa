#### \{{unless_gt}}
_Unless greater than (Unless x > y)_
Parameters: `none`

```html
\{{#unless_gt x compare=y}} ... \{{/unless_gt}}
```
Author: Dan Harper <http://github.com/danharper>