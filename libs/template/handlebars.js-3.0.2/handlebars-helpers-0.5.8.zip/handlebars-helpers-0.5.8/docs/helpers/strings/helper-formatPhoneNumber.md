#### \{{formatPhoneNumber}}
_Output a formatted phone number_

Credit: [Treehouse Blog](http://blog.teamtreehouse.com/handlebars-js-part-2-partials-and-helpers)

Data:

```javascript
number: 4444444444
```
Template:

```html
\{{formatPhoneNumber number}}
```
Renders to:

```
(444) 444-4444
```
