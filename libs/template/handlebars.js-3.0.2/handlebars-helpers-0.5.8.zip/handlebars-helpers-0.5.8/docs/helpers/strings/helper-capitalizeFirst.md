#### \{{capitalizeFirst}}
_Capitalizes the first word in a string._
<br>Parameters: `none`

```html
\{{capitalizeFirst "capitalize first word in this sentence"}}
```
Renders to:

```
Capitalize first word in this sentence
```