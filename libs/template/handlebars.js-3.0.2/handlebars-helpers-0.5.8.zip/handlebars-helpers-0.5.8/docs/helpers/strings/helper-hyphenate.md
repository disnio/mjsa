#### \{{hyphenate}}
_Replace spaces in string with hyphens._
<br>Parameters: `none`

```html
\{{hyphenate "make this all hyphenated"}}
```
Result:

```
make-this-all-hyphenated
```