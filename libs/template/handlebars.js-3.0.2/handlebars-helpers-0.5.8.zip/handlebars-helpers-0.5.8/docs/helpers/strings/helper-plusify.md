#### \{{plusify}}
_Same as `hyphenate`, but replaces spaces in string with plus signs._
<br>Parameters: `none`

```html
\{{dashify "make this all plusified"}}
```
Renders to:
```
make+this+all+plusified
```
