#### \{{sentence}}
_Capitalizes the first word of each sentence in a string and converts the rest of the sentence to lowercase._
Parameters: `none`

```html
\{{sentence "capitalize the FIRST word in each sentence. but make the OTHER words lowercase."}}
```
Renders to:

```
Capitalize the first word in each sentence. But make the other words lowercase.
```