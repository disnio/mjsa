#### \{{occurrences}}
_Evaluate string A, and count the occurrences of string B within string A_
<br>Default: `undefined`
<br>Parameters:
* `String A` (required): The string to evaluate
* `String B` (required): The string to look for and count in "string A"


```html
\{{occurrences "evaluate this string" "i"}}
```
Result:

```
2
```