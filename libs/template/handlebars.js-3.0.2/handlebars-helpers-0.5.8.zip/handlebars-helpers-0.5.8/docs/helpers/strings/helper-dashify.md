#### \{{dashify}}
_Same as `hyphenate`, but replaces dots in string with hyphens._
<br>Parameters: `none`

```html
\{{dashify "make.this.all.hyphenated"}}
```
Renders to:
```
make-this-all-hyphenated
```