#### \{{floor}}
_Returns the value rounded down to the nearest integer._
<br>Parameters: `none`

Data:

```javascript
value = 5.6
```
Template:

```html
\{{floor value}}
```
Renders to:

```
5
```
