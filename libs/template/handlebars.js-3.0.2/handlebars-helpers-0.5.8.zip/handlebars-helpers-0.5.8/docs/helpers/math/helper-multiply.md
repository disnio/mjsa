#### \{{multiply}}
_Returns the multiplication of two numbers._
<br>Parameters: value `int` - The number to multiply the expression. (Required)

Data:

```javascript
value = 5

```
Template:

```html
\{{multiply value 5}}
```
Renders to:

```
25
```
