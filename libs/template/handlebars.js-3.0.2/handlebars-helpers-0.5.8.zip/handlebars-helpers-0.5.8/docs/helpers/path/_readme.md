Path helpers are [node.js](http://nodejs.org/api/path.html) utilities for handling and transforming file paths. As with node.js:

> "these helpers perform only string transformations. The file system is not consulted to check whether paths are valid."

