#### \{{toInt}}
_Returns an integer._

Parameters: `none`

Data:

```javascript
value = '22.2abc'
```

Template:

```html
\{{toInt value}}
```

Renders to:

```
22
```
