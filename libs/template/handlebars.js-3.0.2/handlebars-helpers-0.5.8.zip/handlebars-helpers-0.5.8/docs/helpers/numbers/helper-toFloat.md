#### \{{toFloat}}
_Returns a floating point number._

Parameters: `none`

Data:

```javascript
value = '22.2abc'
```

Template:

```html
\{{toFloat value}}
```

Renders to:

```
22.2
```
