#### \{{addCommas}}
_Adds commas to a number._

Parameters: `none`

Data:

```javascript
value = 2222222
```

Template:

```html
\{{addCommas value}}
```
Renders to:

```
2,222,222
```
