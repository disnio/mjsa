#### \{{length}}
_Returns the length of the collection._
<br>Parameters: `none`

Data:

```json
"collection": [
  "Amy Wong",
  "Bender",
  "Dr. Zoidberg",
  "Fry",
  "Hermes Conrad",
  "Leela",
  "Professor Farnsworth",
  "Scruffy"
]
```

Template:

```html
\{{length collection}}
```

Renders to:

```html
8
```