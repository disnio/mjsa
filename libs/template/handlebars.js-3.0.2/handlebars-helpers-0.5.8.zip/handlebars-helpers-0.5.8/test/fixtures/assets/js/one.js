(function(){
  console.log('foo');
})();