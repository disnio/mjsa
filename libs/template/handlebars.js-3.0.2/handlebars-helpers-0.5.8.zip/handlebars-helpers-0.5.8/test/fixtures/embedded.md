## Markdown

Code example

```js
var urlresolve = function (base, href) {
  return url.resolve(base, href);
};
```

[Click here](http://assemble.io) for more documentation.
