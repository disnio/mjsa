* 2013-04-07    v0.1.21    Add markdown helpers back, add more tests.
* 2013-04-06    v0.1.20    Generalized helpers structure, externalized utilities.
* 2013-04-05    v0.1.11    New authors and gist helpers, general cleanup and new tests.
* 2013-04-04    v0.1.10    Externalized utility javascript from helpers.js
* 2013-03-28    v0.1.8    Gruntfile updated with mocha tests for 71 helpers, bug fixes.
* 2013-03-18    v0.1.7    New path helper "relative", for resolving relative path from one absolute path to another.
* 2013-03-16    v0.1.3    New helpers, "formatPhoneNumber" and "eachProperty"
* 2013-03-15    v0.1.2    Update README.md with documentation, examples.
* 2013-03-06    v0.1.0    First commit.