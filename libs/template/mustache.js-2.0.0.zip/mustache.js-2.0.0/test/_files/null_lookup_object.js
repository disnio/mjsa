({
    "name": "David",
    "twitter": "@dasilvacontin",
    "fobject": [
    	{
    		"name": "Flor",
    		"twitter": "@florrts"
    	},
    	{
	        "name": "Miquel",
	        "twitter": null
	    },
	    {
	    	"name": "Chris",
	        "twitter": undefined
	    }
    ]
})
