angular-dotdotot
================

Angular directive for applying the dotdotdot jquery plugin- http://dotdotdot.frebsite.nl/
