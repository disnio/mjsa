## From jQuery To AngularJS

This is the slides for my talk at [BarcelonaJS](http://barcelonajs.org/), "From jQuery to AngularJS".

See the slides here: http://victorbjelkholm.github.io/from-jquery-to-angularjs/

[@victorbjelkholm](http://twitter.com/victorbjelkholm)


[github.com/victorbjelkholm](http://github.com/victorbjelkholm)