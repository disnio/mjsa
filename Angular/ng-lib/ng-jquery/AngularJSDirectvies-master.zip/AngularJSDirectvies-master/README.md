AngularJSDirectvies
===================

helpful angularjs directives for integrating jquery ui and other things
