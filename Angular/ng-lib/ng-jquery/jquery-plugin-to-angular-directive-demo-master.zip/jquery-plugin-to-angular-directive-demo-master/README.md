Demo files for tttv.co.il tutorial:
Turning a jQuery Plugin to an Angular Directive

