angular-jquery-colorbox
=======================

angular using jquery colorbox
this sample need run in server,because in file not in same domain


This plug-in base on Colorbox v1.4.33 - 2013-10-31

Reference:
    http://www.jacklmoore.com/colorbox/
    http://stackoverflow.com/questions/14641791/how-to-use-colorbox-with-angular-js
    https://groups.google.com/forum/#!topic/angular/zVrcnW_l3aQ - Aaron Smith
