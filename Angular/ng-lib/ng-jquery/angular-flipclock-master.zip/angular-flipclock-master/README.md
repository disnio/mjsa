# angular-flipclock
wrapper for FlipClock.js jQuery plugin (http://flipclockjs.com/)
