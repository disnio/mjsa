angular-layout
==============

JQuery UI Layout directive for angular
