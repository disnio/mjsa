(function () {
  'use strict';
  $.fn.optionTree = sinon.spy();
}());
