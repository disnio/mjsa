kc-angular-numeric
==================

Simple directive to constrain a text input to numeric values, using JQuery numeric lib


Installation :

Include in your html :

1. jquery numeric js source  (see http://www.texotela.co.uk/code/jquery/numeric/)
2. kc-angular-numeric.js
3. angularJs

In your angular application import "kc-angular-numeric" module

Usage : 
```html
<input type=text" numeric-field="">
```
