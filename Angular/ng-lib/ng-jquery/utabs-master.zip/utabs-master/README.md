utabs
======

Simple directive for angular + jQuery UI tabs
