var myApp = angular.module('myApp', ['tabsController', 'utabs']);

var tabsController = angular.module('tabsController', []);
tabsController.controller('tabsController',['$scope', function($scope) {
}]);

var utabs = angular.module('utabs', []);
utabs.directive("utabs", function() {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            element.tabs();
        }
    }
});
